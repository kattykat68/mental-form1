
export default async function handler(req, res) {
  if (req.method === "POST") {
    const sheetURL = "https://script.google.com/macros/s/YOUR_WEBAPP_URL/exec";
    const response = await fetch(sheetURL, {
      method: "POST",
      body: JSON.stringify(req.body),
    });
    const result = await response.text();
    res.status(200).json({ message: result });
  } else {
    res.status(405).send("Method Not Allowed");
  }
}
