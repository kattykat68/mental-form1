
import { useState } from "react";
import axios from "axios";

export default function Home() {
  const [formData, setFormData] = useState({
    mood: "",
    stress: "",
    selfCare: "",
    usedDrug: "",
    message: "",
    date: new Date().toLocaleDateString("en-GB"),
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    await axios.post("/api/submit", formData);
    alert("ขอบคุณที่ดูแลใจตัวเองวันนี้ 💚");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-green-50 font-sans">
      <h1 className="text-2xl font-bold mb-4 text-green-800">🧠 แบบฟอร์มสุขภาพจิตรายวัน</h1>

      <div className="space-y-3 w-full max-w-md">
        <label>
          อารมณ์วันนี้:
          <input type="text" name="mood" onChange={handleChange} className="w-full p-2 border rounded" />
        </label>

        <label>
          ระดับความเครียด (1-10):
          <input type="number" name="stress" onChange={handleChange} className="w-full p-2 border rounded" />
        </label>

        <label>
          ได้ดูแลใจตัวเองอย่างไร:
          <input type="text" name="selfCare" onChange={handleChange} className="w-full p-2 border rounded" />
        </label>

        <label>
          วันนี้คุณใช้สารเสพติดหรือไม่?
          <div className="flex gap-4 mt-1">
            <label className="flex items-center gap-1">
              <input type="radio" name="usedDrug" value="ไม่ได้ใช้" onChange={handleChange} /> ไม่ได้ใช้
            </label>
            <label className="flex items-center gap-1">
              <input type="radio" name="usedDrug" value="ใช้" onChange={handleChange} /> ใช้
            </label>
          </div>
        </label>

        <label>
          ข้อความถึงตัวเองวันนี้:
          <textarea name="message" onChange={handleChange} className="w-full p-2 border rounded" />
        </label>

        <button onClick={handleSubmit} className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition">
          ส่งข้อมูล
        </button>
      </div>
    </div>
  );
}
